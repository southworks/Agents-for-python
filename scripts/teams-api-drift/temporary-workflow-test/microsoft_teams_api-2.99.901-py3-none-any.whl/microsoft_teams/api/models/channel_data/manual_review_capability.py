"""A deliberately additive API used to exercise review classification."""

from ..custom_base_model import CustomBaseModel


class ManualReviewCapability(CustomBaseModel):
    """An unused addition within the mapped channel-data capability."""

    enabled: bool = False
