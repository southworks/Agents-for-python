"""A deliberately unmapped API used to exercise no-action classification."""


class ManualNoActionProbe:
    """An unused addition outside all configured capability areas."""

    enabled: bool = False
